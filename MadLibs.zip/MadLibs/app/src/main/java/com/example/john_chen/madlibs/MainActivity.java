package com.example.john_chen.madlibs;

/*
Name: Bingzhen Chne
CSCI 343 ASSIGNMENT 02
Email: bchen@coastal.edu
 */
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button startButton = (Button)findViewById(R.id.startButton);

        final Intent intent = new Intent(this, Activity2.class);

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Spinner spinner = findViewById(R.id.spinner);

                String Name=String.valueOf(spinner.getSelectedItem());

                intent.putExtra("storyName",Name);

                startActivity(intent);
            }
        });

    }



}
