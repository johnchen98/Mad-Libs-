package com.example.john_chen.madlibs;

/*
Name: Bingzhen Chne
CSCI 343 ASSIGNMENT 02
Email: bchen@coastal.edu
 */

import android.content.Intent;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

public class Activity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);


        TextView storyTextView = (TextView)findViewById(R.id.storyTextView);

        Intent intent = getIntent();

        String story = intent.getStringExtra("Text");

        storyTextView.setText(story);

        Button anotherButton = (Button)findViewById(R.id.anotherButton);

        final Intent intent1 = new Intent(this,MainActivity.class);

        anotherButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent1);
            }
        });
    }


}
