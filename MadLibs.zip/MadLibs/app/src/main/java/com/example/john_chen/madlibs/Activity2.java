package com.example.john_chen.madlibs;
/*
Name: Bingzhen Chne
CSCI 343 ASSIGNMENT 02
Email: bchen@coastal.edu
 */

import android.content.Intent;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

public class Activity2 extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);



        Button keepButton = (Button) findViewById(R.id.keepButton);
        final TextView wordsTextView = (TextView) findViewById(R.id.wordsTextView);
        final EditText wordsEditText = (EditText) findViewById(R.id.wordsEditText);
        final TextView typeTextView = (TextView) findViewById(R.id.typeTextView);
        final Button okButton = (Button) findViewById(R.id.okButton);

        final Resources resource = getResources();

        Intent intent = getIntent();

        String string = intent.getStringExtra("storyName");

        final Intent intent1 = new Intent(this, Activity3.class);

        String fileName =resource.getString(R.string.story);

        if(string.equalsIgnoreCase("tarzan")) {

            fileName = resource.getString(R.string.tarzan);
        }
        else if (string.equalsIgnoreCase("university")){
            fileName = resource.getString(R.string.university);
        }
        else if (string.equalsIgnoreCase("clothes")){
            fileName = resource.getString(R.string.clothes);
        }
        else if (string.equalsIgnoreCase("dance")){
            fileName = resource.getString(R.string.dance);
        }


        keepButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent1);
            }
        });

        Log.d("Debug", "fileName is:" + fileName);
        AssetManager assetManager = getAssets();

        try {
            InputStream inputStream = assetManager.open(fileName);

            final MadLibStory madLibStory = new MadLibStory(inputStream);

            int numberOfWords = madLibStory.getPlaceholderRemainingCount() ;
            wordsTextView.setText(numberOfWords + " word(s) left");
            String type = madLibStory.getNextPlaceholder();
            typeTextView.setText("Please type a/an " + type);

            okButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    madLibStory.fillInPlaceholder(wordsEditText.getText().toString());

                    int numberOfWords = madLibStory.getPlaceholderRemainingCount();

                    wordsTextView.setText(numberOfWords + " word(s) left");

                    String type = madLibStory.getNextPlaceholder();

                    typeTextView.setText("Please type a/an " + type);

                    if(numberOfWords == 0){
                        typeTextView.setText("Finished typing!");
                        intent1.putExtra("Text", madLibStory.toString());

                    }


                }
            });


        } catch (IOException ioe) {
            Log.e("IO ERROR", ioe.getMessage());
        }
    }


}
